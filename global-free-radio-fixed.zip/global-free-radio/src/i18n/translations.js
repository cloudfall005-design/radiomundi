// Translations for Global Free Radio
export const translations = {
  pt: {
    // Header
    'header.title': 'Global Free Radio',
    'header.subtitle': 'Estações de rádio online gratuitas',
    'header.search.placeholder': 'Buscar estações...',
    'header.countries': 'Países',
    'header.genres': 'Gêneros',
    'header.top10': 'Top 10',
    'header.add_station': 'Adicionar Estação',
    'header.all_countries': 'Todos os Países',
    'header.all_genres': 'Todos os Gêneros',
    
    // Home page
    'home.hero.title': 'Global Free Radio',
    'home.hero.subtitle': 'Descubra estações de rádio online gratuitas de todo o mundo',
    'home.stats.countries': 'Países',
    'home.stats.stations': 'Estações',
    'home.stats.online': 'Online',
    'home.stats.free': 'Gratuito',
    'home.explore.title': 'Explorar por Categoria',
    'home.featured.title': 'Estações em Destaque',
    'home.favorites.title': 'Suas Favoritas',
    
    // Search results
    'search.results_for': 'Resultados para',
    'search.filtered_stations': 'Estações Filtradas',
    'search.stations_found': 'estações encontradas',
    'search.searching': 'Buscando estações...',
    'search.no_results': 'Nenhuma estação encontrada. Tente uma busca diferente.',
    
    // Player
    'player.select_station': 'Selecione uma estação para começar a ouvir',
    'player.recently_played': 'Reproduzidas Recentemente:',
    'player.error.play': 'Erro ao reproduzir a estação. Tente novamente.',
    'player.error.load': 'Erro ao carregar a estação. Verifique sua conexão.',
    
    // Top 10
    'top10.title': 'Top 10',
    'top10.most_listened': 'Mais Ouvidas',
    'top10.most_voted': 'Mais Votadas',
    'top10.recently_added': 'Recém Adicionadas',
    'top10.loading': 'Carregando ranking...',
    'top10.listened': 'Ouvidas',
    'top10.voted': 'Votadas',
    'top10.recent': 'Recentes',
    
    // Station card
    'station.listeners': 'ouvintes',
    'station.loading_countries': 'Carregando países...',
    'station.loading_genres': 'Carregando gêneros...',
    'station.show_all': 'Mostrar todas as estações',
    
    // Common
    'common.loading': 'Carregando...',
    'common.error': 'Erro',
    'common.close': '×',
    'common.24_7': '24/7',
    'common.100_percent': '100%',
  },
  
  en: {
    // Header
    'header.title': 'Global Free Radio',
    'header.subtitle': 'Free online radio stations',
    'header.search.placeholder': 'Search stations...',
    'header.countries': 'Countries',
    'header.genres': 'Genres',
    'header.top10': 'Top 10',
    'header.add_station': 'Add Station',
    'header.all_countries': 'All Countries',
    'header.all_genres': 'All Genres',
    
    // Home page
    'home.hero.title': 'Global Free Radio',
    'home.hero.subtitle': 'Discover free online radio stations from around the world',
    'home.stats.countries': 'Countries',
    'home.stats.stations': 'Stations',
    'home.stats.online': 'Online',
    'home.stats.free': 'Free',
    'home.explore.title': 'Explore by Category',
    'home.featured.title': 'Featured Stations',
    'home.favorites.title': 'Your Favorites',
    
    // Search results
    'search.results_for': 'Results for',
    'search.filtered_stations': 'Filtered Stations',
    'search.stations_found': 'stations found',
    'search.searching': 'Searching stations...',
    'search.no_results': 'No stations found. Try a different search.',
    
    // Player
    'player.select_station': 'Select a station to start listening',
    'player.recently_played': 'Recently Played:',
    'player.error.play': 'Error playing station. Please try again.',
    'player.error.load': 'Error loading station. Check your connection.',
    
    // Top 10
    'top10.title': 'Top 10',
    'top10.most_listened': 'Most Listened',
    'top10.most_voted': 'Most Voted',
    'top10.recently_added': 'Recently Added',
    'top10.loading': 'Loading ranking...',
    'top10.listened': 'Listened',
    'top10.voted': 'Voted',
    'top10.recent': 'Recent',
    
    // Station card
    'station.listeners': 'listeners',
    'station.loading_countries': 'Loading countries...',
    'station.loading_genres': 'Loading genres...',
    'station.show_all': 'Show all stations',
    
    // Common
    'common.loading': 'Loading...',
    'common.error': 'Error',
    'common.close': '×',
    'common.24_7': '24/7',
    'common.100_percent': '100%',
  },
  
  es: {
    // Header
    'header.title': 'Global Free Radio',
    'header.subtitle': 'Estaciones de radio online gratuitas',
    'header.search.placeholder': 'Buscar estaciones...',
    'header.countries': 'Países',
    'header.genres': 'Géneros',
    'header.top10': 'Top 10',
    'header.add_station': 'Agregar Estación',
    'header.all_countries': 'Todos los Países',
    'header.all_genres': 'Todos los Géneros',
    
    // Home page
    'home.hero.title': 'Global Free Radio',
    'home.hero.subtitle': 'Descubre estaciones de radio online gratuitas de todo el mundo',
    'home.stats.countries': 'Países',
    'home.stats.stations': 'Estaciones',
    'home.stats.online': 'En línea',
    'home.stats.free': 'Gratis',
    'home.explore.title': 'Explorar por Categoría',
    'home.featured.title': 'Estaciones Destacadas',
    'home.favorites.title': 'Tus Favoritas',
    
    // Search results
    'search.results_for': 'Resultados para',
    'search.filtered_stations': 'Estaciones Filtradas',
    'search.stations_found': 'estaciones encontradas',
    'search.searching': 'Buscando estaciones...',
    'search.no_results': 'No se encontraron estaciones. Prueba una búsqueda diferente.',
    
    // Player
    'player.select_station': 'Selecciona una estación para empezar a escuchar',
    'player.recently_played': 'Reproducidas Recientemente:',
    'player.error.play': 'Error al reproducir la estación. Inténtalo de nuevo.',
    'player.error.load': 'Error al cargar la estación. Verifica tu conexión.',
    
    // Top 10
    'top10.title': 'Top 10',
    'top10.most_listened': 'Más Escuchadas',
    'top10.most_voted': 'Más Votadas',
    'top10.recently_added': 'Recién Agregadas',
    'top10.loading': 'Cargando ranking...',
    'top10.listened': 'Escuchadas',
    'top10.voted': 'Votadas',
    'top10.recent': 'Recientes',
    
    // Station card
    'station.listeners': 'oyentes',
    'station.loading_countries': 'Cargando países...',
    'station.loading_genres': 'Cargando géneros...',
    'station.show_all': 'Mostrar todas las estaciones',
    
    // Common
    'common.loading': 'Cargando...',
    'common.error': 'Error',
    'common.close': '×',
    'common.24_7': '24/7',
    'common.100_percent': '100%',
  },
  
  fr: {
    // Header
    'header.title': 'Global Free Radio',
    'header.subtitle': 'Stations de radio en ligne gratuites',
    'header.search.placeholder': 'Rechercher des stations...',
    'header.countries': 'Pays',
    'header.genres': 'Genres',
    'header.top10': 'Top 10',
    'header.add_station': 'Ajouter une Station',
    'header.all_countries': 'Tous les Pays',
    'header.all_genres': 'Tous les Genres',
    
    // Home page
    'home.hero.title': 'Global Free Radio',
    'home.hero.subtitle': 'Découvrez des stations de radio en ligne gratuites du monde entier',
    'home.stats.countries': 'Pays',
    'home.stats.stations': 'Stations',
    'home.stats.online': 'En ligne',
    'home.stats.free': 'Gratuit',
    'home.explore.title': 'Explorer par Catégorie',
    'home.featured.title': 'Stations en Vedette',
    'home.favorites.title': 'Vos Favoris',
    
    // Search results
    'search.results_for': 'Résultats pour',
    'search.filtered_stations': 'Stations Filtrées',
    'search.stations_found': 'stations trouvées',
    'search.searching': 'Recherche de stations...',
    'search.no_results': 'Aucune station trouvée. Essayez une recherche différente.',
    
    // Player
    'player.select_station': 'Sélectionnez une station pour commencer à écouter',
    'player.recently_played': 'Récemment Jouées:',
    'player.error.play': 'Erreur lors de la lecture de la station. Veuillez réessayer.',
    'player.error.load': 'Erreur lors du chargement de la station. Vérifiez votre connexion.',
    
    // Top 10
    'top10.title': 'Top 10',
    'top10.most_listened': 'Plus Écoutées',
    'top10.most_voted': 'Plus Votées',
    'top10.recently_added': 'Récemment Ajoutées',
    'top10.loading': 'Chargement du classement...',
    'top10.listened': 'Écoutées',
    'top10.voted': 'Votées',
    'top10.recent': 'Récentes',
    
    // Station card
    'station.listeners': 'auditeurs',
    'station.loading_countries': 'Chargement des pays...',
    'station.loading_genres': 'Chargement des genres...',
    'station.show_all': 'Afficher toutes les stations',
    
    // Common
    'common.loading': 'Chargement...',
    'common.error': 'Erreur',
    'common.close': '×',
    'common.24_7': '24/7',
    'common.100_percent': '100%',
  },
  
  de: {
    // Header
    'header.title': 'Global Free Radio',
    'header.subtitle': 'Kostenlose Online-Radiosender',
    'header.search.placeholder': 'Sender suchen...',
    'header.countries': 'Länder',
    'header.genres': 'Genres',
    'header.top10': 'Top 10',
    'header.add_station': 'Sender hinzufügen',
    'header.all_countries': 'Alle Länder',
    'header.all_genres': 'Alle Genres',
    
    // Home page
    'home.hero.title': 'Global Free Radio',
    'home.hero.subtitle': 'Entdecken Sie kostenlose Online-Radiosender aus aller Welt',
    'home.stats.countries': 'Länder',
    'home.stats.stations': 'Sender',
    'home.stats.online': 'Online',
    'home.stats.free': 'Kostenlos',
    'home.explore.title': 'Nach Kategorie erkunden',
    'home.featured.title': 'Empfohlene Sender',
    'home.favorites.title': 'Ihre Favoriten',
    
    // Search results
    'search.results_for': 'Ergebnisse für',
    'search.filtered_stations': 'Gefilterte Sender',
    'search.stations_found': 'Sender gefunden',
    'search.searching': 'Sender suchen...',
    'search.no_results': 'Keine Sender gefunden. Versuchen Sie eine andere Suche.',
    
    // Player
    'player.select_station': 'Wählen Sie einen Sender zum Anhören',
    'player.recently_played': 'Kürzlich gespielt:',
    'player.error.play': 'Fehler beim Abspielen des Senders. Bitte versuchen Sie es erneut.',
    'player.error.load': 'Fehler beim Laden des Senders. Überprüfen Sie Ihre Verbindung.',
    
    // Top 10
    'top10.title': 'Top 10',
    'top10.most_listened': 'Meistgehört',
    'top10.most_voted': 'Bestbewertet',
    'top10.recently_added': 'Kürzlich hinzugefügt',
    'top10.loading': 'Rangliste wird geladen...',
    'top10.listened': 'Gehört',
    'top10.voted': 'Bewertet',
    'top10.recent': 'Aktuell',
    
    // Station card
    'station.listeners': 'Zuhörer',
    'station.loading_countries': 'Länder werden geladen...',
    'station.loading_genres': 'Genres werden geladen...',
    'station.show_all': 'Alle Sender anzeigen',
    
    // Common
    'common.loading': 'Wird geladen...',
    'common.error': 'Fehler',
    'common.close': '×',
    'common.24_7': '24/7',
    'common.100_percent': '100%',
  }
}

// Language names for the language selector
export const languageNames = {
  pt: 'Português',
  en: 'English',
  es: 'Español',
  fr: 'Français',
  de: 'Deutsch'
}

// Default language
export const defaultLanguage = 'pt'

// Get translation function
export const getTranslation = (key, language = defaultLanguage) => {
  return translations[language]?.[key] || translations[defaultLanguage]?.[key] || key
}

// Get browser language
export const getBrowserLanguage = () => {
  const browserLang = navigator.language.split('-')[0]
  return translations[browserLang] ? browserLang : defaultLanguage
}

