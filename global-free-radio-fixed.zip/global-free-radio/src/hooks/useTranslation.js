import { useState, useEffect } from 'react'
import { getTranslation, getBrowserLanguage, defaultLanguage } from '../i18n/translations'

export const useTranslation = () => {
  const [language, setLanguage] = useState(() => {
    // Try to get language from localStorage first, then browser, then default
    const savedLanguage = localStorage.getItem('radio-language')
    if (savedLanguage) return savedLanguage
    return getBrowserLanguage()
  })

  // Save language to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('radio-language', language)
  }, [language])

  // Translation function
  const t = (key) => getTranslation(key, language)

  // Change language function
  const changeLanguage = (newLanguage) => {
    setLanguage(newLanguage)
  }

  return {
    language,
    changeLanguage,
    t
  }
}

