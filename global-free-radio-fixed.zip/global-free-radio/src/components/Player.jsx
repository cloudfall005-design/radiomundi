import { useState, useRef, useEffect } from 'react'
import { Play, Pause, Volume2, VolumeX, Heart, ExternalLink, Loader2, AlertCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Slider } from '@/components/ui/slider'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

const Player = ({ currentStation, isPlaying, onPlay, onPause, isFavorite, onToggleFavorite, volume: externalVolume, onVolumeChange }) => {
  const [volume, setVolume] = useState(externalVolume ? [externalVolume] : [70])
  const [isMuted, setIsMuted] = useState(false)
  const [imageError, setImageError] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState(null)
  const [playHistory, setPlayHistory] = useState([])
  const [actualUrl, setActualUrl] = useState(null)
  const audioRef = useRef(null)

  // Sync external volume changes
  useEffect(() => {
    if (externalVolume !== undefined) {
      setVolume([externalVolume])
    }
  }, [externalVolume])

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume[0] / 100
    }
    if (onVolumeChange) {
      onVolumeChange(volume[0])
    }
  }, [volume, onVolumeChange])

  // Function to resolve the actual streaming URL
  const resolveStreamUrl = async (station) => {
    try {
      // First try to get the resolved URL from the API
      if (station.url_resolved) {
        return station.url_resolved
      }

      // If no resolved URL, try to click the station to get the actual URL
      const clickResponse = await fetch(`https://de1.api.radio-browser.info/json/url/${station.stationuuid}`)
      if (clickResponse.ok) {
        const clickData = await clickResponse.json()
        if (clickData.url) {
          return clickData.url
        }
      }

      // Fallback to the original URL
      return station.url
    } catch (error) {
      console.error('Error resolving stream URL:', error)
      return station.url
    }
  }

  useEffect(() => {
    const handleAudioPlay = async () => {
      if (isPlaying && currentStation && audioRef.current) {
        try {
          setIsLoading(true)
          setError(null)
          
          // Resolve the actual streaming URL
          const streamUrl = await resolveStreamUrl(currentStation)
          setActualUrl(streamUrl)
          
          // Set the audio source
          audioRef.current.src = streamUrl
          
          // Try to play
          await audioRef.current.play()
          
        } catch (err) {
          console.error('Audio play error:', err)
          let errorMessage = 'Erro ao reproduzir a estação.'
          
          if (err.name === 'NotSupportedError') {
            errorMessage = 'Formato de áudio não suportado.'
          } else if (err.name === 'NotAllowedError') {
            errorMessage = 'Reprodução bloqueada pelo navegador. Clique para permitir.'
          } else if (err.name === 'AbortError') {
            errorMessage = 'Reprodução interrompida.'
          }
          
          setError(errorMessage)
          setIsLoading(false)
          onPause()
        }
      } else if (audioRef.current) {
        audioRef.current.pause()
        setIsLoading(false)
      }
    }

    handleAudioPlay()
  }, [isPlaying, currentStation])

  // Load play history from localStorage
  useEffect(() => {
    const savedHistory = localStorage.getItem('radio-play-history')
    if (savedHistory) {
      setPlayHistory(JSON.parse(savedHistory))
    }
  }, [])

  // Save to play history when station starts playing
  useEffect(() => {
    if (isPlaying && currentStation) {
      const newHistory = [
        {
          ...currentStation,
          playedAt: new Date().toISOString()
        },
        ...playHistory.filter(item => item.stationuuid !== currentStation.stationuuid).slice(0, 9)
      ]
      setPlayHistory(newHistory)
      localStorage.setItem('radio-play-history', JSON.stringify(newHistory))
    }
  }, [isPlaying, currentStation])

  const handlePlayPause = () => {
    if (isPlaying) {
      onPause()
    } else if (currentStation) {
      onPlay(currentStation)
    }
  }

  const handleMute = () => {
    if (audioRef.current) {
      audioRef.current.muted = !isMuted
      setIsMuted(!isMuted)
    }
  }

  const handleAudioLoad = () => {
    setIsLoading(false)
    setError(null)
  }

  const handleAudioError = (e) => {
    console.error('Audio error:', e.target.error)
    let errorMessage = 'Erro ao carregar a estação.'
    
    if (e.target.error) {
      switch (e.target.error.code) {
        case e.target.error.MEDIA_ERR_ABORTED:
          errorMessage = 'Reprodução cancelada.'
          break
        case e.target.error.MEDIA_ERR_NETWORK:
          errorMessage = 'Erro de rede. Verifique sua conexão.'
          break
        case e.target.error.MEDIA_ERR_DECODE:
          errorMessage = 'Erro ao decodificar o áudio.'
          break
        case e.target.error.MEDIA_ERR_SRC_NOT_SUPPORTED:
          errorMessage = 'Formato de áudio não suportado.'
          break
        default:
          errorMessage = 'Erro desconhecido ao reproduzir.'
      }
    }
    
    setError(errorMessage)
    setIsLoading(false)
    onPause()
  }

  const handleCanPlay = () => {
    setIsLoading(false)
    setError(null)
  }

  const handleWaiting = () => {
    setIsLoading(true)
  }

  const handlePlaying = () => {
    setIsLoading(false)
    setError(null)
  }

  const getFlagEmoji = (countryCode) => {
    if (!countryCode || countryCode.length !== 2) return '🌍'
    const codePoints = countryCode
      .toUpperCase()
      .split('')
      .map(char => 127397 + char.charCodeAt())
    return String.fromCodePoint(...codePoints)
  }

  const retryPlay = () => {
    if (currentStation) {
      setError(null)
      onPlay(currentStation)
    }
  }

  if (!currentStation) {
    return (
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-card/95 backdrop-blur-sm border-t border-border">
        <div className="container mx-auto">
          <Card className="glass-effect">
            <CardContent className="p-4">
              <div className="flex items-center justify-center text-muted-foreground">
                <p>Selecione uma estação para começar a ouvir</p>
              </div>
              
              {/* Play History */}
              {playHistory.length > 0 && (
                <div className="mt-4">
                  <h4 className="text-sm font-medium mb-2">Reproduzidas Recentemente:</h4>
                  <div className="flex flex-wrap gap-2">
                    {playHistory.slice(0, 5).map((station) => (
                      <Button
                        key={station.stationuuid}
                        variant="outline"
                        size="sm"
                        onClick={() => onPlay(station)}
                        className="text-xs"
                      >
                        {getFlagEmoji(station.countrycode)} {station.name}
                      </Button>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 p-4 bg-card/95 backdrop-blur-sm border-t border-border z-40">
      <div className="container mx-auto">
        <Card className="retro-glow">
          <CardContent className="p-4">
            {/* Error Display */}
            {error && (
              <div className="mb-3 p-2 bg-destructive/10 border border-destructive/20 rounded-md flex items-center space-x-2">
                <AlertCircle className="h-4 w-4 text-destructive" />
                <span className="text-sm text-destructive">{error}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={retryPlay}
                  className="ml-auto"
                >
                  Tentar Novamente
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setError(null)}
                >
                  ×
                </Button>
              </div>
            )}

            <div className="flex items-center space-x-4">
              {/* Station Info */}
              <div className="flex items-center space-x-3 flex-1 min-w-0">
                {/* Station Logo */}
                <div className="flex-shrink-0">
                  {currentStation.favicon && !imageError ? (
                    <img
                      src={currentStation.favicon}
                      alt={currentStation.name}
                      className="w-12 h-12 rounded-lg object-cover"
                      onError={() => setImageError(true)}
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                      <Volume2 className="h-6 w-6 text-white" />
                    </div>
                  )}
                </div>

                {/* Station Details */}
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-foreground truncate neon-text">
                    {currentStation.name}
                  </h3>
                  <div className="flex items-center space-x-2">
                    <span className="text-lg">{getFlagEmoji(currentStation.countrycode)}</span>
                    <span className="text-sm text-muted-foreground truncate">
                      {currentStation.country}
                    </span>
                    {currentStation.codec && (
                      <Badge variant="secondary" className="text-xs">
                        {currentStation.codec} {currentStation.bitrate && `${currentStation.bitrate}k`}
                      </Badge>
                    )}
                  </div>
                  {actualUrl && (
                    <div className="text-xs text-muted-foreground truncate mt-1">
                      {actualUrl}
                    </div>
                  )}
                </div>

                {/* Loading/Equalizer Animation */}
                <div className="hidden sm:flex items-center">
                  {isLoading ? (
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  ) : isPlaying ? (
                    <div className="flex items-end space-x-1 h-8">
                      {[1, 2, 3, 4, 5].map((bar) => (
                        <div
                          key={bar}
                          className="equalizer-bar bg-primary w-1 rounded-t"
                          style={{ height: '10px' }}
                        />
                      ))}
                    </div>
                  ) : null}
                </div>
              </div>

              {/* Controls */}
              <div className="flex items-center space-x-4">
                {/* Action Buttons */}
                <div className="hidden sm:flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onToggleFavorite(currentStation)}
                  >
                    <Heart className={`h-4 w-4 ${isFavorite ? 'fill-red-500 text-red-500' : ''}`} />
                  </Button>
                  
                  {currentStation.homepage && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => window.open(currentStation.homepage, '_blank')}
                    >
                      <ExternalLink className="h-4 w-4" />
                    </Button>
                  )}
                </div>

                {/* Play/Pause Button */}
                <Button
                  onClick={handlePlayPause}
                  size="lg"
                  disabled={isLoading}
                  className="bg-primary hover:bg-primary/80"
                >
                  {isLoading ? (
                    <Loader2 className="h-5 w-5 animate-spin" />
                  ) : isPlaying ? (
                    <Pause className="h-5 w-5" />
                  ) : (
                    <Play className="h-5 w-5" />
                  )}
                </Button>

                {/* Volume Control */}
                <div className="hidden md:flex items-center space-x-2 w-32">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={handleMute}
                  >
                    {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                  </Button>
                  <Slider
                    value={volume}
                    onValueChange={setVolume}
                    max={100}
                    step={1}
                    className="flex-1"
                  />
                </div>
              </div>
            </div>

            {/* Mobile Volume Control */}
            <div className="md:hidden mt-4 flex items-center space-x-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={handleMute}
              >
                {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
              </Button>
              <Slider
                value={volume}
                onValueChange={setVolume}
                max={100}
                step={1}
                className="flex-1"
              />
              
              {/* Mobile Action Buttons */}
              <div className="flex items-center space-x-1">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onToggleFavorite(currentStation)}
                >
                  <Heart className={`h-4 w-4 ${isFavorite ? 'fill-red-500 text-red-500' : ''}`} />
                </Button>
                
                {currentStation.homepage && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => window.open(currentStation.homepage, '_blank')}
                  >
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Hidden Audio Element */}
      <audio
        ref={audioRef}
        onError={handleAudioError}
        onLoadStart={() => setIsLoading(true)}
        onCanPlay={handleCanPlay}
        onLoadedData={handleAudioLoad}
        onWaiting={handleWaiting}
        onPlaying={handlePlaying}
        preload="none"
        crossOrigin="anonymous"
      />
    </div>
  )
}

export default Player

