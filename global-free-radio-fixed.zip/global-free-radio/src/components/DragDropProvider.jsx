import { createContext, useContext, useState } from 'react'

const DragDropContext = createContext()

export const useDragDrop = () => {
  const context = useContext(DragDropContext)
  if (!context) {
    throw new Error('useDragDrop must be used within a DragDropProvider')
  }
  return context
}

export const DragDropProvider = ({ children }) => {
  const [draggedItem, setDraggedItem] = useState(null)
  const [dragOverItem, setDragOverItem] = useState(null)

  const handleDragStart = (item, type) => {
    setDraggedItem({ item, type })
  }

  const handleDragEnd = () => {
    setDraggedItem(null)
    setDragOverItem(null)
  }

  const handleDragOver = (item) => {
    setDragOverItem(item)
  }

  const handleDrop = (targetItem, onDrop) => {
    if (draggedItem && onDrop) {
      onDrop(draggedItem, targetItem)
    }
    handleDragEnd()
  }

  return (
    <DragDropContext.Provider
      value={{
        draggedItem,
        dragOverItem,
        handleDragStart,
        handleDragEnd,
        handleDragOver,
        handleDrop
      }}
    >
      {children}
    </DragDropContext.Provider>
  )
}

