import { useState } from 'react'
import { Settings, Palette, Layout, Volume2, X, RotateCcw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Slider } from '@/components/ui/slider'
import { Badge } from '@/components/ui/badge'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu'
import { useTranslation } from '../hooks/useTranslation'

const CustomizationPanel = ({ isOpen, onClose, settings, onSettingsChange }) => {
  const { t } = useTranslation()

  const themes = [
    { id: 'retro-dark', name: 'Retro Dark', colors: ['#8B5CF6', '#06B6D4', '#F59E0B'] },
    { id: 'neon-blue', name: 'Neon Blue', colors: ['#3B82F6', '#06B6D4', '#8B5CF6'] },
    { id: 'cyberpunk', name: 'Cyberpunk', colors: ['#F59E0B', '#EF4444', '#8B5CF6'] },
    { id: 'synthwave', name: 'Synthwave', colors: ['#EC4899', '#8B5CF6', '#06B6D4'] },
    { id: 'matrix', name: 'Matrix', colors: ['#10B981', '#059669', '#047857'] }
  ]

  const layouts = [
    { id: 'grid', name: 'Grade', icon: '⊞' },
    { id: 'list', name: 'Lista', icon: '☰' },
    { id: 'compact', name: 'Compacto', icon: '▤' },
    { id: 'cards', name: 'Cartões', icon: '⊡' }
  ]

  const handleThemeChange = (themeId) => {
    onSettingsChange({ ...settings, theme: themeId })
    // Apply theme to document
    document.documentElement.setAttribute('data-theme', themeId)
  }

  const handleLayoutChange = (layoutId) => {
    onSettingsChange({ ...settings, layout: layoutId })
  }

  const handleAnimationToggle = () => {
    onSettingsChange({ ...settings, animations: !settings.animations })
  }

  const handleAutoplayToggle = () => {
    onSettingsChange({ ...settings, autoplay: !settings.autoplay })
  }

  const resetSettings = () => {
    const defaultSettings = {
      theme: 'retro-dark',
      layout: 'grid',
      animations: true,
      autoplay: false,
      volume: [70],
      showFlags: true,
      showGenres: true,
      compactMode: false
    }
    onSettingsChange(defaultSettings)
    document.documentElement.setAttribute('data-theme', 'retro-dark')
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto glass-effect">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Settings className="h-5 w-5" />
            <span>Personalização</span>
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Theme Selection */}
          <div>
            <h3 className="text-lg font-semibold mb-3 flex items-center">
              <Palette className="h-4 w-4 mr-2" />
              Tema Visual
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {themes.map((theme) => (
                <div
                  key={theme.id}
                  className={`p-3 rounded-lg border cursor-pointer transition-all hover:scale-105 ${
                    settings.theme === theme.id ? 'border-primary bg-primary/10' : 'border-border hover:border-primary/50'
                  }`}
                  onClick={() => handleThemeChange(theme.id)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">{theme.name}</span>
                    {settings.theme === theme.id && (
                      <Badge variant="default" className="text-xs">Ativo</Badge>
                    )}
                  </div>
                  <div className="flex space-x-1">
                    {theme.colors.map((color, index) => (
                      <div
                        key={index}
                        className="w-6 h-6 rounded-full border-2 border-white"
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Layout Selection */}
          <div>
            <h3 className="text-lg font-semibold mb-3 flex items-center">
              <Layout className="h-4 w-4 mr-2" />
              Layout das Estações
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {layouts.map((layout) => (
                <Button
                  key={layout.id}
                  variant={settings.layout === layout.id ? 'default' : 'outline'}
                  className="flex flex-col items-center space-y-2 h-auto py-4"
                  onClick={() => handleLayoutChange(layout.id)}
                >
                  <span className="text-2xl">{layout.icon}</span>
                  <span className="text-sm">{layout.name}</span>
                </Button>
              ))}
            </div>
          </div>

          {/* Audio Settings */}
          <div>
            <h3 className="text-lg font-semibold mb-3 flex items-center">
              <Volume2 className="h-4 w-4 mr-2" />
              Configurações de Áudio
            </h3>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">
                  Volume Padrão: {settings.volume?.[0] || 70}%
                </label>
                <Slider
                  value={settings.volume || [70]}
                  onValueChange={(value) => onSettingsChange({ ...settings, volume: value })}
                  max={100}
                  step={1}
                  className="w-full"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Reprodução Automática</span>
                <Button
                  variant={settings.autoplay ? 'default' : 'outline'}
                  size="sm"
                  onClick={handleAutoplayToggle}
                >
                  {settings.autoplay ? 'Ligado' : 'Desligado'}
                </Button>
              </div>
            </div>
          </div>

          {/* Display Settings */}
          <div>
            <h3 className="text-lg font-semibold mb-3">Configurações de Exibição</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Animações</span>
                <Button
                  variant={settings.animations ? 'default' : 'outline'}
                  size="sm"
                  onClick={handleAnimationToggle}
                >
                  {settings.animations ? 'Ligado' : 'Desligado'}
                </Button>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Mostrar Bandeiras</span>
                <Button
                  variant={settings.showFlags ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => onSettingsChange({ ...settings, showFlags: !settings.showFlags })}
                >
                  {settings.showFlags ? 'Sim' : 'Não'}
                </Button>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Mostrar Gêneros</span>
                <Button
                  variant={settings.showGenres ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => onSettingsChange({ ...settings, showGenres: !settings.showGenres })}
                >
                  {settings.showGenres ? 'Sim' : 'Não'}
                </Button>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Modo Compacto</span>
                <Button
                  variant={settings.compactMode ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => onSettingsChange({ ...settings, compactMode: !settings.compactMode })}
                >
                  {settings.compactMode ? 'Sim' : 'Não'}
                </Button>
              </div>
            </div>
          </div>

          {/* Reset Button */}
          <div className="pt-4 border-t border-border">
            <Button
              variant="outline"
              onClick={resetSettings}
              className="w-full flex items-center space-x-2"
            >
              <RotateCcw className="h-4 w-4" />
              <span>Restaurar Configurações Padrão</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default CustomizationPanel

