import { useState } from 'react'
import { Play, Pause, Heart, ExternalLink, Volume2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

const StationCard = ({ station, isPlaying, onPlay, onPause, isFavorite, onToggleFavorite }) => {
  const [imageError, setImageError] = useState(false)

  const handlePlayPause = () => {
    if (isPlaying) {
      onPause()
    } else {
      onPlay(station)
    }
  }

  const getFlagEmoji = (countryCode) => {
    if (!countryCode || countryCode.length !== 2) return '🌍'
    const codePoints = countryCode
      .toUpperCase()
      .split('')
      .map(char => 127397 + char.charCodeAt())
    return String.fromCodePoint(...codePoints)
  }

  return (
    <Card className="group hover:retro-glow transition-all duration-300 bg-card/50 backdrop-blur-sm">
      <CardContent className="p-4">
        <div className="flex items-start space-x-4">
          {/* Station Logo */}
          <div className="flex-shrink-0">
            {station.favicon && !imageError ? (
              <img
                src={station.favicon}
                alt={station.name}
                className="w-12 h-12 rounded-lg object-cover"
                onError={() => setImageError(true)}
              />
            ) : (
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <Volume2 className="h-6 w-6 text-white" />
              </div>
            )}
          </div>

          {/* Station Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-foreground truncate group-hover:neon-text transition-all">
                  {station.name}
                </h3>
                <div className="flex items-center space-x-2 mt-1">
                  <span className="text-lg">{getFlagEmoji(station.countrycode)}</span>
                  <span className="text-sm text-muted-foreground">{station.country}</span>
                </div>
                {station.tags && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {station.tags.split(',').slice(0, 3).map((tag, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {tag.trim()}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex items-center space-x-2 ml-2">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onToggleFavorite(station)}
                  className="opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Heart className={`h-4 w-4 ${isFavorite ? 'fill-red-500 text-red-500' : ''}`} />
                </Button>
                
                {station.homepage && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => window.open(station.homepage, '_blank')}
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                )}

                <Button
                  onClick={handlePlayPause}
                  className={`${isPlaying ? 'bg-accent hover:bg-accent/80' : 'bg-primary hover:bg-primary/80'}`}
                >
                  {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            {/* Station Details */}
            <div className="flex items-center space-x-4 mt-3 text-xs text-muted-foreground">
              {station.codec && (
                <span className="bg-muted px-2 py-1 rounded">{station.codec}</span>
              )}
              {station.bitrate && (
                <span className="bg-muted px-2 py-1 rounded">{station.bitrate} kbps</span>
              )}
              {station.clickcount > 0 && (
                <span>👥 {station.clickcount} ouvintes</span>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default StationCard

