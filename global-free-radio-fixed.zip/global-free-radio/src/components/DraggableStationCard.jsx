import { useState } from 'react'
import { Play, Pause, Heart, ExternalLink, GripVertical, Star } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useDragDrop } from './DragDropProvider'

const DraggableStationCard = ({ 
  station, 
  isPlaying, 
  onPlay, 
  onPause, 
  isFavorite, 
  onToggleFavorite,
  isDraggable = false,
  onReorder
}) => {
  const [imageError, setImageError] = useState(false)
  const { draggedItem, dragOverItem, handleDragStart, handleDragEnd, handleDragOver, handleDrop } = useDragDrop()

  const getFlagEmoji = (countryCode) => {
    if (!countryCode || countryCode.length !== 2) return '🌍'
    const codePoints = countryCode
      .toUpperCase()
      .split('')
      .map(char => 127397 + char.charCodeAt())
    return String.fromCodePoint(...codePoints)
  }

  const handlePlayPause = () => {
    if (isPlaying) {
      onPause()
    } else {
      onPlay(station)
    }
  }

  const isDraggedOver = dragOverItem?.stationuuid === station.stationuuid
  const isBeingDragged = draggedItem?.item?.stationuuid === station.stationuuid

  return (
    <Card 
      className={`glass-effect hover:retro-glow transition-all duration-200 ${
        isPlaying ? 'ring-2 ring-primary' : ''
      } ${isDraggedOver ? 'ring-2 ring-accent scale-105' : ''} ${
        isBeingDragged ? 'opacity-50 scale-95' : ''
      }`}
      draggable={isDraggable}
      onDragStart={(e) => {
        if (isDraggable) {
          handleDragStart(station, 'station')
          e.dataTransfer.effectAllowed = 'move'
        }
      }}
      onDragEnd={handleDragEnd}
      onDragOver={(e) => {
        if (isDraggable) {
          e.preventDefault()
          handleDragOver(station)
        }
      }}
      onDrop={(e) => {
        if (isDraggable) {
          e.preventDefault()
          handleDrop(station, onReorder)
        }
      }}
    >
      <CardContent className="p-4">
        <div className="flex items-center space-x-3">
          {/* Drag Handle */}
          {isDraggable && (
            <div className="cursor-grab active:cursor-grabbing text-muted-foreground hover:text-foreground">
              <GripVertical className="h-4 w-4" />
            </div>
          )}

          {/* Station Logo */}
          <div className="flex-shrink-0">
            {station.favicon && !imageError ? (
              <img
                src={station.favicon}
                alt={station.name}
                className="w-12 h-12 rounded-lg object-cover"
                onError={() => setImageError(true)}
              />
            ) : (
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <span className="text-lg">{getFlagEmoji(station.countrycode)}</span>
              </div>
            )}
          </div>

          {/* Station Info */}
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-foreground truncate">
              {station.name}
            </h3>
            <div className="flex items-center space-x-2 mt-1">
              <span className="text-sm">{getFlagEmoji(station.countrycode)}</span>
              <span className="text-sm text-muted-foreground truncate">
                {station.country}
              </span>
            </div>
            
            {/* Tags */}
            {station.tags && (
              <div className="flex flex-wrap gap-1 mt-2">
                {station.tags.split(',').slice(0, 3).map((tag, index) => (
                  <Badge key={index} variant="secondary" className="text-xs">
                    {tag.trim()}
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Station Stats */}
          <div className="text-right text-sm text-muted-foreground">
            {station.codec && (
              <div className="font-medium">{station.codec}</div>
            )}
            {station.bitrate && (
              <div>{station.bitrate}k</div>
            )}
            {station.clickcount > 0 && (
              <div className="flex items-center space-x-1">
                <span>👥</span>
                <span>{station.clickcount}</span>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onToggleFavorite(station)}
              className="hover:scale-110 transition-transform"
            >
              <Heart className={`h-4 w-4 ${isFavorite ? 'fill-red-500 text-red-500' : ''}`} />
            </Button>
            
            {station.homepage && (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => window.open(station.homepage, '_blank')}
                className="hover:scale-110 transition-transform"
              >
                <ExternalLink className="h-4 w-4" />
              </Button>
            )}

            <Button
              onClick={handlePlayPause}
              size="icon"
              className={`${isPlaying ? 'bg-accent hover:bg-accent/80' : 'bg-primary hover:bg-primary/80'} hover:scale-110 transition-transform`}
            >
              {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        {/* Equalizer Animation */}
        {isPlaying && (
          <div className="flex items-end justify-center space-x-1 mt-3 h-6">
            {[1, 2, 3, 4, 5].map((bar) => (
              <div
                key={bar}
                className="equalizer-bar bg-primary w-1 rounded-t"
                style={{ 
                  height: '8px',
                  animationDelay: `${bar * 0.1}s`
                }}
              />
            ))}
          </div>
        )}

        {/* Favorite Star */}
        {isFavorite && (
          <div className="absolute top-2 right-2">
            <Star className="h-4 w-4 fill-yellow-500 text-yellow-500" />
          </div>
        )}
      </CardContent>
    </Card>
  )
}

export default DraggableStationCard

